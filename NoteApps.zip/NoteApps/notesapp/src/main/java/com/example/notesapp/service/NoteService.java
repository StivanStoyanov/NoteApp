package com.example.notesapp.service;

public interface NoteService{
}
