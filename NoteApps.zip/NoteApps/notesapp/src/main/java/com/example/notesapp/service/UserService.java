package com.example.notesapp.service;

import com.example.notesapp.model.dto.UserRegisterDTO;

public interface UserService {
    void register(UserRegisterDTO userRegisterDTO);
}
