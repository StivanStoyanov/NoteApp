package com.example.notesapp.service.Impl;

import com.example.notesapp.service.NoteService;
import org.springframework.stereotype.Service;

@Service
public class NoteServiceImpl implements NoteService {

}
